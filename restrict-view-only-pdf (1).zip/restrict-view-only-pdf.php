<?php
/**
 * Plugin Name: RestrictViewOnlyPDF
 * Description: Restrict access to specific pages unless the user has purchased the corresponding WooCommerce products.
 * Version: 2.1
 * Author: Dev.shubho
 */

// Enqueue FontAwesome for the admin panel
function load_fontawesome_in_admin() {
    if ( is_admin() ) {
        wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css' );
    }
}
add_action( 'admin_enqueue_scripts', 'load_fontawesome_in_admin' );

// Add menu for plugin settings
function restrict_pdf_access_settings_menu() {
    add_menu_page(
        'RestrictViewOnlyPDF Settings',
        'RestrictViewOnlyPDF',
        'manage_options',
        'restrictviewonlypdf',
        'restrict_pdf_access_settings_page',
        'dashicons-lock',
        20
    );
}
add_action( 'admin_menu', 'restrict_pdf_access_settings_menu' );

// Render the settings page
function restrict_pdf_access_settings_page() {
    $rules = get_option('restrict_pdf_access_rules', []);
    ?>
    <div class="wrap">
        <h2><i class="fas fa-lock"></i> RestrictViewOnlyPDF Settings</h2>
        <form method="post" action="options.php">
            <?php
                settings_fields( 'restrict_pdf_access_options' );
                do_settings_sections( 'restrictviewonlypdf' );
            ?>
            <table class="form-table" id="rules-table">
                <tr>
                    <th>Page Slug</th>
                    <th>Product ID</th>
                    <th>Redirect URL</th>
                    <th>Action</th>
                </tr>
                <?php if ( ! empty($rules) ) {
                    foreach ($rules as $index => $rule) {
                        echo '<tr>
                            <td><input type="text" name="restrict_pdf_access_rules['.$index.'][slug]" value="'.esc_attr($rule['slug']).'" /></td>
                            <td><input type="text" name="restrict_pdf_access_rules['.$index.'][product_id]" value="'.esc_attr($rule['product_id']).'" /></td>
                            <td><input type="text" name="restrict_pdf_access_rules['.$index.'][redirect]" value="'.esc_attr($rule['redirect'] ?? '') .'" /></td>
                            <td><button type="button" class="button delete-rule-row">Delete</button></td>
                        </tr>';
                    }
                } else {
                    echo '<tr>
                        <td><input type="text" name="restrict_pdf_access_rules[0][slug]" /></td>
                        <td><input type="text" name="restrict_pdf_access_rules[0][product_id]" /></td>
                        <td><input type="text" name="restrict_pdf_access_rules[0][redirect]" /></td>
                        <td><button type="button" class="button delete-rule-row">Delete</button></td>
                    </tr>';
                } ?>
            </table>
            <p><button type="button" onclick="addRuleRow()" class="button">Add More</button></p>
            <?php submit_button(); ?>
        </form>
    </div>

    <script>
    function addRuleRow() {
        const table = document.getElementById('rules-table');
        let lastIndex = 0;

        const inputs = table.querySelectorAll('input[name^="restrict_pdf_access_rules"]');
        inputs.forEach(input => {
            const match = input.name.match(/restrict_pdf_access_rules\[(\d+)\]/);
            if (match && parseInt(match[1]) >= lastIndex) {
                lastIndex = parseInt(match[1]) + 1;
            }
        });

        const row = table.insertRow(-1);
        row.innerHTML = `
            <td><input type="text" name="restrict_pdf_access_rules[${lastIndex}][slug]" /></td>
            <td><input type="text" name="restrict_pdf_access_rules[${lastIndex}][product_id]" /></td>
            <td><input type="text" name="restrict_pdf_access_rules[${lastIndex}][redirect]" /></td>
            <td><button type="button" class="button delete-rule-row">Delete</button></td>
        `;
    }

    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('delete-rule-row')) {
            const row = e.target.closest('tr');
            if (row) row.remove();
        }
    });
    </script>
    <?php
}

// Register settings
function restrict_pdf_access_register_settings() {
    register_setting( 'restrict_pdf_access_options', 'restrict_pdf_access_rules' );
}
add_action( 'admin_init', 'restrict_pdf_access_register_settings' );

// Enforce access restrictions
function restrict_pdf_access_page() {
    $rules = get_option('restrict_pdf_access_rules', []);

    if ( empty($rules) ) return;

    foreach ($rules as $rule) {
        if ( isset($rule['slug'], $rule['product_id']) && is_page($rule['slug']) ) {
            if ( ! is_user_logged_in() ) {
                wp_redirect( home_url('/my-account/') );
                exit;
            }
            $user_id = get_current_user_id();
            if ( ! wc_customer_bought_product( '', $user_id, $rule['product_id'] ) ) {
                $redirect = isset($rule['redirect']) ? $rule['redirect'] : '/shop';
                wp_redirect( home_url($redirect) );
                exit;
            }
        }
    }
}
add_action( 'template_redirect', 'restrict_pdf_access_page' );
